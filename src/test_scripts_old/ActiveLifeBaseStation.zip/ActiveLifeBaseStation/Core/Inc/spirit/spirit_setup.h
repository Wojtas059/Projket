/*
 * spirit_setup.h
 *
 *  Created on: Dec 3, 2021
 *      Author: steelph0enix
 */

#ifndef INC_SPIRIT_SPIRIT_SETUP_H_
#define INC_SPIRIT_SPIRIT_SETUP_H_

void spirit_setup_handle();
void spirit_setup_config();
void spirit_setup_irq();

#endif /* INC_SPIRIT_SPIRIT_SETUP_H_ */
