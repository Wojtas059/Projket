# S2-LP Library

This library provides a simple way to use S2-LP transciever module. This library is WIP, but mostly done.

https://www.st.com/en/wireless-connectivity/s2-lp.html

## Porting instructions

See `s2lp_mcu_interface.h` and `s2lp_mcu_interface.c` for details

